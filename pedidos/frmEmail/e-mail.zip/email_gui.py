# -*- coding: utf-8 -*-

from PyQt5 import QtSql, QtGui, QtWidgets, Qt
from PyQt5.QtGui import QStandardItemModel, QStandardItem, QBrush, QColor
# from PyQt5.QtWidgets import QMessageBox
import imaplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime
import os
import email
import csv
import sys


class Ui(QtWidgets.QDialog):

    # Definição da Classe e dos Widgets
    def __init__(self, ui=None):
        super(Ui, self).__init__()  # Chama as classes herdadas o método __init__
        ui.loadUi("frmReservas.ui", self)  # Carrega o arquivo de interface (.ui)

        # Localizando os widgets por nome dentro do arquivo ui
        # Dando nomes locais para widget "importados"
        self.btRegistrar = self.findChild(QtWidgets.QPushButton, 'btRegistrar')
        self.btEmail = self.findChild(QtWidgets.QPushButton, 'btEmail')
        self.txtNome = self.findChild(QtWidgets.QLineEdit, 'txtNome')
        self.txtCelular = self.findChild(QtWidgets.QLineEdit, 'txtCelular')
        self.txtEmail = self.findChild(QtWidgets.QLineEdit, 'txtEmail')
        self.tblEmails = self.findChild(QtWidgets.QTableView, 'QTVEmail')
        self.lblStatus = self.findChild(QtWidgets.QLabel, 'lblStatus')
        self.pbProgresso = self.findChild(QtWidgets.QProgressBar, 'pbProgresso')
        self.chkArquivar = self.findChild(QtWidgets.QCheckBox, 'chkArquivar')
        self.chkEmail = self.findChild(QtWidgets.QCheckBox, 'chkEmail')
        self.chkMySQL = self.findChild(QtWidgets.QCheckBox, 'chkMysql')
        self.txtData = self.findChild(QtWidgets.QLineEdit, 'txtData')
        self.lstVariedades = self.findChild(QtWidgets.QListView, 'lstVariedades')

        self.MY_SQL_HOST = "10.1.1.254"

        # Preencher cada widget com os valores iniciais

        # Conectar cada widget que pode ter uma ação à função específica (Sinais)
        self.btRegistrar.clicked.connect(self.Registrar)  # Lembre de passar a definição do método não o valor de retono
        self.btEmail.clicked.connect(self.download_arquivos)

        # Define propriedades extra dos Widgets
        self.pbProgresso.setVisible(False)
        # Mostra a interface gráfica
        self.show()

    def download_arquivos(self):
        app.setOverrideCursor(Qt.WaitCursor)
        self.pbProgresso.setVisible(True)
        # Conecta no servidor
        mail = imaplib.IMAP4_SSL("uscentral30.myserverhosts.com", 993)
        # Autentica
        mail.login("comercial@clona-gen.com.br", "clona@2019")
        # Seleciona a Caixa de Entrada
        mail.select('Inbox')
        # Filtra os emails que tem o Assunto: Interessados
        type, data = mail.search(None, '(SUBJECT "Interessado")')
        mail_ids = data[0]
        # Lista os ids que foram selecionados
        id_list = mail_ids.split()
        # Atualiza a label de status
        self.lblStatus.setText("Foram encontrados " + str(len(id_list)) + " e-mails.")
        # Atualiza a barra de progresso
        self.pbProgresso.setRange(0, len(id_list) - 1)
        self.pbProgresso.setValue(0)
        print("Encontrados " + str(len(id_list)) + " e-mails.")
        i = 0
        for num in data[0].split():
            self.pbProgresso.setValue(i)
            print("-------------------------")
            print("Processando e-mail " + str(num))
            print("-------------------------")
            # Atualizando Label
            self.lblStatus.setText("Processando e-mail " + str(i) + "(" + str(num) + ")")
            typ, data = mail.fetch(num, '(RFC822)')
            raw_email = data[0][1]
            raw_email_string = raw_email.decode('latin-1')
            email_message = email.message_from_string(raw_email_string)
            # Download do Anexo
            for part in email_message.walk():
                # this part comes from the snipped I don't understand yet...
                if part.get_content_maintype() == 'multipart':
                    continue
                if part.get('Content-Disposition') is None:
                    continue
                # Pego o nome do anexo
                fileName = part.get_filename()
                if bool(fileName):
                    fileName = "Reserva_" + str(i) + ".csv"
                    filePath = os.path.join('.', fileName)
                    if not os.path.isfile(filePath):
                        fp = open(filePath, 'wb')
                        part.set_charset("utf-8")
                        fp.write(part.get_payload(decode=True))
                        fp.close()
                    print('Baixado Arquivo "{file}"'.format(file=fileName))
                    # Se a checkbox estiver ativada arquiva senão não
                    if self.chkArquivar.isChecked():
                        mail.copy(num, "inbox.interessados")
            i += 1

        for response_part in data:
            if isinstance(response_part, tuple):
                msg = email.message_from_string(response_part[1].decode('utf-8'))
                email_subject = msg['subject']
                email_from = msg['from']
                print('De : ' + email_from + '\n')
                # print ('Subject : ' + email_subject + '\n')
                # print(msg.get_payload(decode=True))
        self.pbProgresso.setVisible(False)
        self.lblStatus.setText(str(i) + " e-mails processados")
        self.preenche_QTableView()
        app.restoreOverrideCursor()

    def preenche_QTableView(self):
        # formata o datagrid e cria o dataModel
        self.model = QStandardItemModel()
        # Formata o número de colunas
        self.model.setColumnCount(7)
        # Dá nome para as colunas
        headerNames = []
        headerNames.append("Id")
        headerNames.append("Data")
        headerNames.append("Nome")
        headerNames.append("Cidade")
        headerNames.append("e-mail")
        headerNames.append("Fone")
        headerNames.append("Interesse")
        # Atribui o nome ao model
        self.model.setHorizontalHeaderLabels(headerNames)
        # Padrão de seleção por linhas
        self.tblEmails.setSelectionBehavior(self.tblEmails.SelectRows)
        # Habilita a ordenação
        self.tblEmails.setSortingEnabled(True)

        # Processa o arquivo baixado
        lista_arquivos = self.lista_arquivos_csv(os.curdir, ".csv")
        # Variável para contar os aquivos
        i = 0
        for arquivo in lista_arquivos:
            # Abre o arquivo CSV
            with open(arquivo, encoding='utf-8') as csv_file:
                print("Abrindo arquivo CSV")
                csv_reader = csv.reader(csv_file, delimiter=',')
                line_count = 0
                # Para cada linha do arquivo faz o processamento
                for row in csv_reader:
                    if line_count == 0:
                        # pula o cabecalho do arquivo
                        line_count += 1
                    else:
                        # Pré processa as variáveis
                        mail_ID = QStandardItem(f"{i:04d}")
                        mail_Data = QStandardItem(row[0])
                        mail_Nome = QStandardItem(row[1].title())
                        mail_Cidade = QStandardItem(row[2].title())
                        mail_Email = QStandardItem(row[3].lower())
                        mail_Fone = QStandardItem(self.formata_telefone(row[4]))
                        mail_Interesse = QStandardItem(row[5])
                        # print('Data:',mail_Data,'\nNome: ',mail_Nome,'\nCidade:',mail_Cidade,'\nEmail: ',mail_Email,'\nFone: ',mail_Fone,'\nInteresse: ',mail_Interesse)

                        # Atribui cada uma das variáveis a uma coluna do model na linha selecionada
                        self.model.setItem(i, 0, mail_ID)
                        self.model.setItem(i, 1, mail_Data)
                        self.model.setItem(i, 2, mail_Nome)
                        self.model.setItem(i, 3, mail_Cidade)
                        self.model.setItem(i, 4, mail_Email)
                        self.model.setItem(i, 5, mail_Fone)
                        self.model.setItem(i, 6, mail_Interesse)
                        i = i + 1
        # Atribui os dados à tabela
        self.tblEmails.setModel(self.model)
        # Não parece estar funcionando
        self.tblEmails.setColumnWidth(0, 45)  # Id
        self.tblEmails.setColumnWidth(1, 90)  # Data
        self.tblEmails.setColumnWidth(2, 250)  # Nome
        self.tblEmails.setColumnWidth(3, 120)  # Cidade
        self.tblEmails.setColumnWidth(4, 250)  # Email
        self.tblEmails.setColumnWidth(5, 150)  # Fone
        self.tblEmails.setColumnWidth(6, 250)  # Interesse
        # Pega somente os selecionados
        self.Selecionados = self.tblEmails.selectionModel()
        # Ao clicar dispara "Info_linha"
        self.Selecionados.selectionChanged.connect(self.info_linha)
        font = QtGui.QFont("Verdana", 8)
        self.tblEmails.setFont(font)
        # Desabilita o botão de Email
        self.btEmail.setEnabled(False)
        self.chkArquivar.setEnabled(False)

    def formata_telefone(self, txtFone):
        # Limpa os caracteres especiais
        for char in txtFone:
            if char in "() -*#/":
                txtFone = txtFone.replace(char, "")
        # Verifica se é celular
        if len(txtFone) == 11:
            telFormatado = "({}) {}{}-{}".format(txtFone[0:2], txtFone[2], txtFone[3:7], txtFone[7:])
        # Telefone Fixo
        elif len(txtFone) == 10:
            telFormatado = "({}) {}-{}".format(txtFone[0:2], txtFone[2:6], txtFone[6:])
        # Ou se o cliente fez muitas anotações, retorna como está
        else:
            telFormatado = txtFone
        return telFormatado

    def lista_arquivos_csv(self, path_to_dir, suffix=".csv"):
        filenames = os.listdir(path_to_dir)
        return [filename for filename in filenames if filename.endswith(suffix)]

    def Registrar(self):
        # Define o cursor como Wait
        app.setOverrideCursor(Qt.WaitCursor)
        # Esta parte é executada quanto o botão é pressionado
        # Pega os dados da linha atual selecionada para fazer a inclusão
        indexRows = self.Selecionados.selectedRows()
        # Percorre cada item selecionado (no caso apenas 1 linha)
        for indexRow in sorted(indexRows):
            row = indexRow.row()
        # Preenche os campos com a linha selecionada
        mail_Fone = self.model.item(row, column=5).text()
        mail_Email = self.model.item(row, column=4).text()
        mail_Nome = self.model.item(row, column=2).text()
        mail_Data = self.model.item(row, column=1).text()
        mail_Cidade = self.model.item(row, column=3).text()
        mail_Interesse = self.model.item(row, column=6).text()
        if self.chkMySQL.isChecked():
            self.registra_reserva(mail_Data, mail_Nome, mail_Cidade, mail_Email, mail_Fone, mail_Interesse)
        if self.chkEmail.isChecked():
            self.envia_email(mail_Nome, mail_Email, mail_Interesse)
        cor_fundo = QColor(251, 236, 93, 127)
        # Tem que pintar célula por célula de cada linha
        for i in range(0, 6):
            self.model.setData(self.model.index(row, i), QBrush(cor_fundo), Qt.BackgroundRole)
        # restaura o cursor de ponteiro
        app.restoreOverrideCursor()

    def info_linha(self, index):
        # Pega os dados da linha clicada e coloca nos campos
        indexRows = self.Selecionados.selectedRows()
        for indexRow in sorted(indexRows):
            row = indexRow.row()
        # Preenche os campos com a linha selecionada
        self.txtCelular.setText(self.model.item(row, column=5).text())
        self.txtEmail.setText(self.model.item(row, column=4).text())
        self.txtNome.setText(self.model.item(row, column=2).text())
        self.txtData.setText(self.model.item(row, column=1).text())
        self.txtCidade.setText(self.model.item(row, column=3).text())
        # Preenche a lista com as mudas de interesse
        # self.lstVariedades.

    def registra_reserva(self, data, nome, cidade, email, fone, interesse):
        sql_Reserva = QtSql.QSqlQuery()
        sql_Reserva.prepare(
            "INSERT INTO reservas SET Data=:data,Nome=:nome,Fone=:fone,Email=:email,Cidade=:cidade,UF=:uf,Atendido=:atendido)")
        # Prepara  as variáveis
        varData = datetime.datetime.strptime(data, "%m/%d/%Y")
        varNome = nome.title()
        varFone = fone
        varEmail = email.lower()
        varCidade = cidade[:-3]
        varUf = cidade[-2:]
        # Preenche os valores
        sql_Reserva.bindValue(':data', varData)
        sql_Reserva.bindValue(':nome', varNome)
        sql_Reserva.bindValue(':fone', varFone)
        sql_Reserva.bindValue(':email', varEmail)
        sql_Reserva.bindValue(':cidade', varCidade)
        sql_Reserva.bindValue(':uf', varUf)
        sql_Reserva.bindValue(':atendido', 0)
        from PyQt5.QtSql import QSqlError
        try:
            # Confirma se o pedido foi incluido com sucesso
            if sql_Reserva.exec():
                # **** INCLUSÃO DOS ITENS ****
                id_reserva = sql_Reserva.lastInsertId()
                print("Pedido Inserido: " + str(id_reserva))
                # Percorre os ítens da tabela para fazer a inclusão
                numLinhas = self.ui.tblItens.rowCount()
                print(str(numLinhas) + " itens a incluir")
                print('Linha inserida', id_reserva)

                # Vamos à inserção dos ítens
                for varClone in ("396", "397", "398", "399", "400", "401"):
                    if (varClone in interesse):
                        sql_Item = QtSql.QSqlQuery()
                        sql_Item.prepare(
                            "INSERT INTO reservas_itens SET `Doc_ID`=:docid,`Mercadoria`=:mercadoria,`Clone`=:clone,`Descricao`=:descricao,`Quantidade`=:qtde,`Preco`=:preco,`Forma`=:forma")
                        # Prepara as variáveis auxiliáres
                        sql_Item.bindValue(':docid', id_reserva)
                        sql_Item.bindValue(':mercadoria', 45)
                        sql_Item.bindValue(':clone', varClone)
                        sql_Item.bindValue(':descricao', "Manihota esculenta cv. BRS-" + varClone)
                        sql_Item.bindValue(':quantidade', 25)
                        sql_Item.bindValue(':preco', 2.50)
                        sql_Item.bindValue(':forma', "Muda Aclimatizada")
                        try:
                            sql_Item.exec()
                        except QSqlError as err:
                            print(err.text())
                    else:
                        print('Linha não inserida')
        except QSqlError as e:
            print(e.text())

    def envia_email(self, Nome, Email, Interesse):
        # Extrai o nome arruma as maiusculas e pega somente o primeiro nome
        tratamento = Nome.split(" ")[0].title()
        variedades = ""
        # Trata as variedades de interesse
        for var in ("396", "397", "398", "399", "400", "401"):
            if (var in Interesse):
                if (len(variedades) == 0):
                    variedades = var
                else:
                    variedades = variedades + ", " + var
        # Carregar texto base do e-mail
        arquivo_html = open("modelo_resposta.html", "r")
        texto_email = arquivo_html.read()
        texto_email = texto_email.replace("[Nome]", tratamento)
        texto_email = texto_email.replace("[saudacao]", "Boa tarde")
        texto_email = texto_email.replace("[variedades]", variedades)
        # Create message container - the correct MIME type is multipart/alternative.
        msg = MIMEMultipart('alternative')
        msg['Subject'] = "Mudas de Mandiocas BRS"
        msg['From'] = "comercial@clona-gen.com.br"
        msg['To'] = Email
        msg['Cc'] = "alexandredrefahl@gmail"
        # Create the body of the message (a plain-text and an HTML version).
        text = "Texto Email"
        html = texto_email
        # Record the MIME types of both parts - text/plain and text/html.
        part1 = MIMEText(text, 'plain')
        part2 = MIMEText(html, 'html')
        # Attach parts into message container.
        # According to RFC 2046, the last part of a multipart message, in this case
        # the HTML message, is best and preferred.
        msg.attach(part1)
        msg.attach(part2)
        # Send the message via local SMTP server.
        server = smtplib.SMTP("uscentral30.myserverhosts.com")
        server.ehlo()
        server.starttls()
        server.login("comercial@clona-gen.com.br", "clona@2019")
        # sendmail function takes 3 arguments: sender's address, recipient's address
        # and message to send - here it is sent as one string.
        server.sendmail("comercial@clona-gen.com.br", [Email, "alexandredrefahl@gmail.com"], msg.as_string())
        print("Email enviado...\r\r")
        server.quit()


app = QtWidgets.QApplication(sys.argv)  # Cria uma instancia da Classe QtWidgets.QApplication
window = Ui()  # Cria uma instancia da nossa classe
app.exec_()  # Incia o aplicativo
